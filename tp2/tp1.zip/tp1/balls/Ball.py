'''
Ball.py

implements the Ball class
Lukas Peraza, 2015 for 15-112 Pygame Lecture
'''
import pygame
import random
from GameObject import GameObject


class Ball(GameObject):
    @staticmethod
    def init():
        image = pygame.image.load('images/kosbie.gif').convert_alpha()
        rows, cols = 4, 4
        width, height = image.get_size()
        cellWidth, cellHeight = width / cols, height / rows
        Ball.images = []
        Ball.images.append(image)
        '''
        for i in range(rows):
            for j in range(cols):
                subImage = image.subsurface(
                    (i * cellWidth, j * cellHeight, cellWidth, cellHeight))
                Ball.images.append(subImage)
        '''
    minSize = 1
    maxSize = 1

    def __init__(self, x, y, level=None):
        if level is None:
            level = random.randint(Ball.minSize, Ball.maxSize)
        self.level = level
        factor = self.level / 5
        image = random.choice(Ball.images)
        w, h = image.get_size()
        image = pygame.transform.scale(image, (int(w * factor), int(h * factor)))
        super(Ball, self).__init__(x, y, image, w / 7 * factor)
        self.angleSpeed = 0 #random.randint(-10, 10)

    def update(self, screenWidth, screenHeight):
        self.angle += self.angleSpeed
        super(Ball, self).update(screenWidth, screenHeight)

    def breakApart(self):
        if self.level == Ball.minSize:
            return []
        else:
            return [Ball(self.x, self.y, self.level - 1),
                    Ball(self.x, self.y, self.level - 1)]
